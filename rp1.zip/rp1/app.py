from flask import Flask, render_template, request, redirect, url_for, session, Response
import mysql.connector
from mysql.connector import Error
import cv2
from utils import send_alert

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a secure key

# Global variables to store Twilio credentials
account_sid = None
auth_token = None
twilio_phone = None
user_phone = None

# Load the pre-trained model
model = cv2.dnn_DetectionModel('mobilenet_iter_73000.caffemodel', 'deploy.prototxt')
model.setInputSize(224, 224)
model.setInputScale(1.0 / 127.5)
model.setInputMean((127.5, 127.5, 127.5))
model.setInputSwapRB(True)

classLabels = ["background", "aeroplane", "bicycle", "bird", "boat",
               "bottle", "bus", "car", "cat", "chair", "cow", "diningtable",
               "dog", "horse", "motorbike", "person", "pottedplant", "sheep",
               "sofa", "train", "tvmonitor"]

def generate_frames():
    cap = cv2.VideoCapture(0)
    while True:
        success, frame = cap.read()
        if not success:
            break

        ClassIndex, confidence, bbox = model.detect(frame, confThreshold=0.99)
        if len(ClassIndex) != 0:
            for ClassInd, conf, boxes in zip(ClassIndex.flatten(), confidence.flatten(), bbox):
                if ClassInd <= len(classLabels):
                    cv2.rectangle(frame, boxes, (255, 0, 0), 2)
                    cv2.putText(frame, classLabels[ClassInd], (boxes[0] + 10, boxes[1] + 40), cv2.FONT_HERSHEY_PLAIN, 3, (0, 255, 0), thickness=3)

                    # Check for cat or dog and send alert
                    if classLabels[ClassInd] in ["cat", "dog"]:
                        send_alert(classLabels[ClassInd], account_sid, auth_token, twilio_phone, user_phone)

        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='Pawan@88820',
        database='surveillance_system'
    )

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/logout')
def logout():
    global account_sid, auth_token, twilio_phone, user_phone
    session.clear()  # Clear user session
    account_sid = None
    auth_token = None
    twilio_phone = None
    user_phone = None
    return redirect(url_for('home'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        
        connection = get_db_connection()
        cursor = connection.cursor()
        
        try:
            cursor.execute('INSERT INTO users (name, email, password) VALUES (%s, %s, %s)', (name, email, password))
            connection.commit()
            return redirect(url_for('signin'))
        except Error as e:
            return f"Error: {e}"
        finally:
            cursor.close()
            connection.close()
    return render_template('register.html')

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    global account_sid, auth_token, twilio_phone, user_phone

    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        try:
            cursor.execute('SELECT * FROM users WHERE email = %s AND password = %s', (email, password))
            user = cursor.fetchone()
            
            if user:
                session['authenticated'] = True

                # Store Twilio credentials in global variables
                account_sid = user.get('account_sid')
                auth_token = user.get('auth_token')
                twilio_phone = user.get('twilio_phone')
                user_phone = user.get('user_phone')

                return redirect(url_for('surveillance'))
            return "Invalid credentials. Please try again."
        except Error as e:
            return f"Error: {e}"
        finally:
            cursor.close()
            connection.close()
    return render_template('signin.html')

@app.route('/surveillance')
def surveillance():
    if 'authenticated' not in session or not session['authenticated']:
        return redirect(url_for('signin'))
    return render_template('surveillance.html')

@app.route('/video_feed')
def video_feed():
    if 'authenticated' not in session or not session['authenticated']:
        return redirect(url_for('signin'))
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True)
