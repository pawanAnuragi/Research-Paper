import time
from twilio.rest import Client

# Store the last alert timestamp
last_alert_time = 0  
ALERT_INTERVAL = 10  # Time interval between alerts (in seconds)

def send_alert(animal_name, account_sid, auth_token, twilio_phone, user_phone):
    global last_alert_time
    current_time = time.time()

    if None in (account_sid, auth_token, twilio_phone, user_phone):
        print("Error: Twilio credentials are not set.")
        return

    if current_time - last_alert_time < ALERT_INTERVAL:
        print("Alert skipped to prevent spamming.")
        return  # Skip sending SMS if it's within the interval

    client = Client(account_sid, auth_token)
    alert_message = f"⚠️ Alert! A {animal_name} has been detected in the poultry farm. Please check the surveillance system."

    try:
        message = client.messages.create(
            body=alert_message,
            from_=twilio_phone,
            to=user_phone
        )
        print(f"SMS sent successfully! Message SID: {message.sid}")

        # Update last alert time
        last_alert_time = current_time  
    except Exception as e:
        print(f"Error sending SMS: {e}")
